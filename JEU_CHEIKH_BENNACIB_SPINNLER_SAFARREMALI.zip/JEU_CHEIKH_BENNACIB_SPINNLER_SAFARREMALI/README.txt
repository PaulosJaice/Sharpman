Quadrinôme:

Anis Cheikh
Ahmed Ben-Nacib
Farrah Zineb
Paul Spinnler

Pour compiler, ouvrez rider avec la solution.
Soyez sûr d'installer avec NuGet les plugins nécéssaires:

1/MonoGame.Content.Builder.Task
2/MonoGame.Framework.DesktopGL
3/MonoGame.Library.SDL
4/NVorbis
5/System.Memory
6/System.ValueTuple





